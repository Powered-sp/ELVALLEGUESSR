(function() {
  console.log("[GeoGuessr Tracker] Content script cargado e iniciado");

  let ultimoUsuario = "";
  let enviado = false;

  // Selectores robustos que no dependen de hashes dinámicos
  const obtenerInputUsuario = () => {
    return document.querySelector('input[placeholder*="apodo" i]') || 
           document.querySelector('input[placeholder*="nick" i]') || 
           document.querySelector('input[placeholder*="name" i]') || 
           document.querySelector('main input[type="text"]') ||
           document.querySelector('input[type="text"]');
  };

  // Selector robusto para la puntuación final
  const obtenerDivPuntuacion = () => {
    return document.querySelector('div[data-qa="final-result-score"]') || 
           document.querySelector('[class*="final-result-score"]') ||
           document.querySelector('[class*="score-wrapper"]');
  };

  function sendData(usuario, puntuacion, dificultad) {
    console.log("[GeoGuessr Tracker] Intentando enviar datos finales:", { usuario, puntuacion, dificultad });
    
    chrome.runtime.sendMessage({ action: "sendData", data: { usuario, puntuacion, dificultad } }, response => {
      if (response?.success) {
        console.log("[Content Script] ¡Datos guardados en Google Sheets con éxito!", response.response);
      } else {
        console.error("[Content Script] Error en la respuesta del Background:", response?.error);
      }
    });
  }

  const observer = new MutationObserver(() => {
    if (enviado) return;

    // 1. Intentar capturar el usuario de forma constante mientras el input exista
    const inputUsuario = obtenerInputUsuario();
    if (inputUsuario) {
      const valorActual = inputUsuario.value.trim();
      if (valorActual && valorActual !== ultimoUsuario) {
        ultimoUsuario = valorActual;
        console.log("[GeoGuessr Tracker] Usuario detectado/actualizado:", ultimoUsuario);
      }
    }

    // 2. Intentar capturar la puntuación final
    const divPuntuacionFinal = obtenerDivPuntuacion();
    if (divPuntuacionFinal) {
      // Limpiamos el texto de espacios, comas o la palabra "pts" (Ej: "24 500" o "24500")
      const textoPuntos = divPuntuacionFinal.textContent.trim().replace(/[^0-9]/g, '');
      const puntos = parseInt(textoPuntos, 10);

      // Si tenemos los puntos válidos y hemos logrado coger un usuario antes de que desapareciera
      if (!isNaN(puntos) && puntos > 0 && ultimoUsuario) {
        const url = window.location.href;
        let dificultad = "Desconocida";

        if (url.includes("nnTSJIccalcpyl4F")) dificultad = "Fácil";
        else if (url.includes("jdZO0BdNSVgLVeI0")) dificultad = "Medio";
        else if (url.includes("NACbl3PruMkTKmeb")) dificultad = "Difícil";
        else if (url.includes("mBBKOpmgVTtCrVvl")) dificultad = "Extremo";

        // Enviamos y desconectamos para evitar bucles
        sendData(ultimoUsuario, puntos, dificultad);
        enviado = true;
        observer.disconnect();
        console.log("[GeoGuessr Tracker] Observer desconectado tras envío exitoso.");
      }
    }
  });

  // Escuchamos todo el body para capturar cambios de pantalla fluidos
  observer.observe(document.body, { childList: true, subtree: true });
})();