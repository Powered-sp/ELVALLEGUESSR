chrome.runtime.onMessage.addListener((req, sender, res) => {
  if (req.action === "finalizarPartida") {
    console.log("[AutoReset] Temporizador letal de 5 segundos iniciado...");
    
    // Exactamente a los 5 segundos ocurre la magia destructiva
    setTimeout(() => {
      // 1. Borrado nuclear de cookies
      chrome.cookies.getAll({ domain: "geoguessr.com" }, (cookies) => {
        if(cookies) {
          cookies.forEach(c => chrome.cookies.remove({ 
            url: (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path, 
            name: c.name 
          }));
        }
      });
      
      // 2. Redirección a la web de sites
      chrome.tabs.update(sender.tab.id, { url: "https://sites.google.com/view/elvalleguessr" }, (updatedTab) => {
        // 3. Dos segundos después de redirigir, matar el resto de pestañas
        setTimeout(() => {
          chrome.tabs.query({}, (tabs) => {
            const tabsToClose = tabs.filter(t => updatedTab && t.id !== updatedTab.id).map(t => t.id);
            if(tabsToClose.length) chrome.tabs.remove(tabsToClose);
          });
        }, 2000);
      });
    }, 5000);
  }
});