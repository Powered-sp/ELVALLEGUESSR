chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "sendData") {
    fetch("https://script.google.com/macros/s/AKfycbysXs2wVadmaU_tq6c4cyCIFnMr4JBs_YjZk5Ps4ycJ9S5Wg2Etm2vwgV4bedkwW58dzg/exec", {
      method: "POST",
      mode: "no-cors",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(message.data)
    })
      .then(() => {
        console.log("[Background] Datos de ronda enviados a Google Sheets.");
        sendResponse({ success: true });
      })
      .catch(error => {
        console.error("[Background] Error enviando datos:", error);
        sendResponse({ success: false, error: error.toString() });
      });
    return true;
  }
});