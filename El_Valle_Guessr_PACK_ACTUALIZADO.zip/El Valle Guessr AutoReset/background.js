chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "finalizarPartida") {
    console.log("[AutoReset] Señal de fin de partida recibida. Iniciando proceso de reseteo...");
    
    // 1. Borrar cookies de GeoGuessr
    chrome.cookies.getAll({ domain: "geoguessr.com" }, function(cookies) {
      for (let cookie of cookies) {
        chrome.cookies.remove({
          url: (cookie.secure ? "https://" : "http://") + cookie.domain + cookie.path,
          name: cookie.name
        });
      }
    });

    // 2. Esperar 5 segundos antes de redirigir
    setTimeout(() => {
      chrome.tabs.update(sender.tab.id, { url: "https://sites.google.com/view/elvalleguessr" }, function(updatedTab) {

        // 3. Esperar 2 segundos más y cerrar las demás pestañas
        setTimeout(() => {
          chrome.tabs.query({}, function(tabs) {
            const tabsToClose = tabs
              .filter(tab => tab.id !== updatedTab.id)
              .map(tab => tab.id);

            chrome.tabs.remove(tabsToClose);
          });
        }, 2000);

      });
    }, 5000);
  }
});