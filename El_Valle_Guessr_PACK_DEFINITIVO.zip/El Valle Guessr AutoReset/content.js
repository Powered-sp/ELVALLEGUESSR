(function() {
  console.log("[AutoReset] Monitor de fin de partida cargado.");
  let desatado = false;

  const observer = new MutationObserver(() => {
    if (desatado) return;

    const textoPantalla = document.body.innerText;
    const tieneContenedorPuntos = !!document.querySelector('[class*="round-result_pointsIndicatorWrapper"]');
    const esPantallaFinal = !!document.querySelector('[data-qa="final-result-score"]') || !!document.querySelector('[class*="final-result-score"]');

    // Condición perfecta: Estamos viendo los puntos de la ronda 5 o la pantalla de resumen final
    if ((textoPantalla.includes("Ronda 5") && tieneContenedorPuntos) || esPantallaFinal) {
      desatado = true;
      console.log("[AutoReset] Fin del juego detectado en pantalla. Notificando al Service Worker...");
      chrome.runtime.sendMessage({ action: "finalizarPartida" });
      observer.disconnect();
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();