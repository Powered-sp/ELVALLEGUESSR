chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "sendData") {
    console.log("[Ranking] Enviando datos al Excel:", message.data);
    fetch("https://script.google.com/macros/s/AKfycbysXs2wVadmaU_tq6c4cyCIFnMr4JBs_YjZk5Ps4ycJ9S5Wg2Etm2vwgV4bedkwW58dzg/exec", {
      method: "POST", mode: "no-cors", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(message.data)
    }).then(() => sendResponse({ success: true })).catch(e => sendResponse({ success: false, error: e.toString() }));
    return true;
  }
});