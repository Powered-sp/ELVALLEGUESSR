while ($true) {
    $edge = Get-Process msedge -ErrorAction SilentlyContinue
    $visible = $false

    foreach ($proc in $edge) {
        try {
            if ($proc.MainWindowHandle -ne 0) {
                $visible = $true
                break
            }
        } catch {}
    }

    if (-not $visible) {
        Start-Process msedge.exe
    }

    Start-Sleep -Seconds 3
}
