(function() {
  console.log("[GeoGuessr Tracker] Iniciado. Monitorizando boton y sumando 5 rondas.");
  let ultimoUsuario = "";
  let puntosTotales = 0;
  let rondasSumadas = 0;
  let pantallaPuntosVisible = false;
  let enviadoFinal = false;

  const obtenerInputUsuario = () => document.querySelector('input[placeholder*="apodo" i]') || document.querySelector('input[placeholder*="nick" i]') || document.querySelector('input[placeholder*="name" i]') || document.querySelector('input[type="text"]');

  const observer = new MutationObserver(() => {
    // 1. Asegurar el nombre de usuario
    const inputUsr = obtenerInputUsuario();
    if (inputUsr && inputUsr.value.trim()) ultimoUsuario = inputUsr.value.trim();

    // 2. Localizar los elementos clave de la ronda
    const botonCerrar = document.querySelector('button[data-qa="close-round-result"]');
    const divPuntos = document.querySelector('[class*="shadow-text_root"]');

    // GeoGuessr anima los números. El botón de Siguiente Ronda o Ver Resultados SOLO aparece
    // cuando la animación de los puntos ha terminado. Por tanto, esto asegura coger el número final.
    if (botonCerrar && divPuntos && !pantallaPuntosVisible) {
      pantallaPuntosVisible = true;
      
      const textoBoton = botonCerrar.innerText || botonCerrar.textContent;
      const esVerResultados = textoBoton.toLowerCase().includes("ver resultados");

      // Limpiamos los puntos para quedarnos con el número puro
      const textoPuntos = (divPuntos.innerText || divPuntos.textContent).replace(/[^0-9]/g, '');
      const puntosRonda = parseInt(textoPuntos, 10);

      // Máximo por ronda son 5000 puntos
      if (!isNaN(puntosRonda) && puntosRonda <= 5000 && rondasSumadas < 5) {
        rondasSumadas++;
        puntosTotales += puntosRonda;
        console.log(`[Ranking] Ronda ${rondasSumadas} sumada: ${puntosRonda} pts. Acumulado: ${puntosTotales} pts.`);

        // Si es el botón definitivo y no hemos enviado aún
        if (esVerResultados && !enviadoFinal && ultimoUsuario) {
          enviadoFinal = true;
          
          const url = window.location.href;
          let dif = "Desconocida";
          if (url.includes("nnTSJIccalcpyl4F")) dif = "Fácil";
          else if (url.includes("jdZO0BdNSVgLVeI0")) dif = "Medio";
          else if (url.includes("NACbl3PruMkTKmeb")) dif = "Difícil";
          else if (url.includes("mBBKOpmgVTtCrVvl")) dif = "Extremo";
          
          console.log("[Ranking] ¡Final detectado! Enviando puntos totales:", puntosTotales);
          chrome.runtime.sendMessage({ action: "sendData", data: { usuario: ultimoUsuario, puntuacion: puntosTotales, dificultad: dif }});
        }
      }
    } else if (!botonCerrar) {
      // Cuando el jugador hace clic y el botón desaparece, reseteamos el estado 
      // para poder sumar la siguiente ronda
      pantallaPuntosVisible = false;
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();