(function() {
  console.log("[AutoReset] Activo. Monitorizando aparición del botón 'Ver resultados'...");
  let ejecutado = false;
  
  const observer = new MutationObserver(() => {
    if (ejecutado) return;
    
    // Buscamos el botón de cierre de ronda por su atributo estricto
    const boton = document.querySelector('button[data-qa="close-round-result"]');
    if (boton) {
      // Analizamos si su texto interior dice 'Ver resultados' (ignora mayúsculas)
      const texto = boton.innerText || boton.textContent;
      if (texto.toLowerCase().includes("ver resultados")) {
        ejecutado = true;
        console.log("[AutoReset] ¡Botón final en pantalla! Lanzando orden de cuenta regresiva de 5s.");
        chrome.runtime.sendMessage({ action: "finalizarPartida" });
        observer.disconnect();
      }
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();