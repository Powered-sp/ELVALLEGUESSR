chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "sendData") {
    fetch("https://script.google.com/macros/s/AKfycbysXs2wVadmaU_tq6c4cyCIFnMr4JBs_YjZk5Ps4ycJ9S5Wg2Etm2vwgV4bedkwW58dzg/exec", {
      method: "POST",
      mode: "no-cors",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(message.data)
    })
      .then(response => response.text())
      .then(text => {
        console.log("[Background] Datos enviados con éxito:", text);
        sendResponse({ success: true, response: text });
      })
      .catch(error => {
        console.error("[Background] Error enviando datos:", error);
        sendResponse({ success: false, error: error.toString() });
      });
    // Indica que la respuesta será asíncrona
    return true;
  }
});