chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "finalizarPartida") {
    console.log("[AutoReset] Señal de cierre recibida. Limpiando cookies...");

    // 1. Borrar todas las cookies del dominio de geoguessr.com
    chrome.cookies.getAll({ domain: "geoguessr.com" }, function(cookies) {
      if (cookies) {
        for (let cookie of cookies) {
          let url = (cookie.secure ? "https://" : "http://") + cookie.domain.replace(/^\./, "") + cookie.path;
          chrome.cookies.remove({ url: url, name: cookie.name });
        }
      }
    });

    // 2. Dar margen de 5 segundos para asegurar que el fetch de 'Ranking' finalizó con éxito
    setTimeout(() => {
      console.log("[AutoReset] Redirigiendo pestaña principal...");
      chrome.tabs.update(sender.tab.id, { url: "https://sites.google.com/view/elvalleguessr" }, function(updatedTab) {
        
        // 3. Dejar el PC limpio de otras pestañas secundarias 2 segundos después
        setTimeout(() => {
          chrome.tabs.query({}, function(tabs) {
            if (tabs) {
              const tabsToClose = tabs
                .filter(tab => updatedTab && tab.id !== updatedTab.id)
                .map(tab => tab.id);
              if (tabsToClose.length > 0) {
                chrome.tabs.remove(tabsToClose);
              }
            }
          });
        }, 2000);

      });
    }, 5000);
  }
});