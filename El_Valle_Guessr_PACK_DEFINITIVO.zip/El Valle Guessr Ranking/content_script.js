(function() {
  console.log("[GeoGuessr Tracker] Content script cargado (Suma por Rondas Activa)");

  let ultimoUsuario = "";
  let puntosTotales = 0;
  let rondasProcesadas = new Set();
  let enviadoFinal = false;

  const obtenerInputUsuario = () => {
    return document.querySelector('input[placeholder*="apodo" i]') || 
           document.querySelector('input[placeholder*="nick" i]') || 
           document.querySelector('input[placeholder*="name" i]') || 
           document.querySelector('main input[type="text"]') ||
           document.querySelector('input[type="text"]');
  };

  const observer = new MutationObserver(() => {
    // 1. Captura del apodo constante
    const inputUsuario = obtenerInputUsuario();
    if (inputUsuario) {
      const valorActual = inputUsuario.value.trim();
      if (valorActual && valorActual !== ultimoUsuario) {
        ultimoUsuario = valorActual;
        console.log("[GeoGuessr Tracker] Apodo capturado:", ultimoUsuario);
      }
    }

    // 2. Localizar el div de puntos usando clase parcial de GeoGuessr
    const wrapperPuntos = document.querySelector('[class*="round-result_pointsIndicatorWrapper"]');
    if (wrapperPuntos) {
      const divTexto = wrapperPuntos.querySelector('[class*="shadow-text_root"]');
      if (divTexto) {
        // Usamos innerText para ignorar nodos HTML ocultos y leer solo el número en pantalla
        const textoVisible = divTexto.innerText || divTexto.textContent;
        const textoLimpio = textoVisible.trim().replace(/[^0-9]/g, '');
        const puntosRonda = parseInt(textoLimpio, 10);

        if (!isNaN(puntosRonda) && puntosRonda <= 5000) {
          // Detectamos de forma segura si estamos textualmente en la Ronda 5
          let rondaActual = rondasProcesadas.size + 1;
          const cuerpoTexto = document.body.innerText;
          
          if (cuerpoTexto.includes("Ronda 5") || document.querySelector('[data-qa="final-result-score"]') || document.querySelector('[class*="final-result-score"]')) {
            rondaActual = 5;
          }

          // Si es una ronda nueva, la acumulamos
          if (!rondasProcesadas.has(rondaActual)) {
            rondasProcesadas.add(rondaActual);
            puntosTotales += puntosRonda;
            console.log(`[GeoGuessr Tracker] Sumada Ronda ${rondaActual}: ${puntosRonda} pts. Acumulado Total: ${puntosTotales} pts.`);

            // Si es la ronda 5, mandamos inmediatamente a Sheets antes de que actúe el AutoReset
            if (rondaActual === 5 && !enviadoFinal && ultimoUsuario) {
              enviadoFinal = true;
              
              const url = window.location.href;
              let dificultad = "Desconocida";
              if (url.includes("nnTSJIccalcpyl4F")) dificultad = "Fácil";
              else if (url.includes("jdZO0BdNSVgLVeI0")) dificultad = "Medio";
              else if (url.includes("NACbl3PruMkTKmeb")) dificultad = "Difícil";
              else if (url.includes("mBBKOpmgVTtCrVvl")) dificultad = "Extremo";

              console.log("[GeoGuessr Tracker] ¡Ronda 5 detectada! Lanzando datos finales:", { usuario: ultimoUsuario, puntuacion: puntosTotales, dificultad });
              
              chrome.runtime.sendMessage({
                action: "sendData",
                data: { usuario: ultimoUsuario, puntuacion: puntosTotales, dificultad: dificultad }
              });
            }
          }
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();