// Detecta si aparece la puntuación de la ronda 5 para activar el AutoReset
const observer = new MutationObserver(() => {
  const wrapperPuntos = document.querySelector('.round-result_pointsIndicatorWrapper__7JxD_');
  if (wrapperPuntos) {
    // Comprobar si estamos textualmente en la Ronda 5
    const elementos = document.querySelectorAll('*');
    let esRonda5 = false;
    for (let el of elementos) {
      if (el.childNodes.length === 1 && el.textContent.includes("Ronda 5")) {
        esRonda5 = true;
        break;
      }
    }
    
    // Alternativa secundaria si cambian los textos: comprobar la cabecera del resultado final
    const resultDivFinal = document.querySelector('[data-qa="final-result-score"]');
    
    if (esRonda5 || resultDivFinal) {
      console.log("[AutoReset] Ronda 5 o Pantalla Final detectada. Mandando orden de cierre...");
      chrome.runtime.sendMessage({ action: "finalizarPartida" });
      observer.disconnect();
    }
  }
});

observer.observe(document.body, { childList: true, subtree: true });