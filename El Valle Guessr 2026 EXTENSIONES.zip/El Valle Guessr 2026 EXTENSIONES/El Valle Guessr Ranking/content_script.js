(function() {
  console.log("[GeoGuessr Tracker] Iniciado. Motor de extracción por bloques numéricos activo.");

  let ultimoUsuario = "";
  let puntosTotales = 0;
  let maxPuntosRondaActiva = -1;
  let pantallaPuntosVisible = false;
  let temporizadorFinalIniciado = false;

  const obtenerInputUsuario = () =>
    document.querySelector('input[placeholder*="apodo" i]') ||
    document.querySelector('input[placeholder*="nick" i]') ||
    document.querySelector('input[placeholder*="name" i]') ||
    document.querySelector('input[type="text"]');

  const observer = new MutationObserver(() => {

    // 1. Guardar nombre usuario
    const inputUsr = obtenerInputUsuario();
    if (inputUsr && inputUsr.value.trim()) {
      ultimoUsuario = inputUsr.value.trim();
    }

    // 2. Botón fin de ronda
    const botonCerrar = document.querySelector('button[data-qa="close-round-result"]');
    const botonVisible = botonCerrar && botonCerrar.offsetParent !== null;

    if (botonVisible) {
      pantallaPuntosVisible = true;

      // 3. 🔥 SOLO PUNTUACIÓN (NO DISTANCIA)
      const nodoPuntos = document.querySelector(
        '.shadow-text_root__KeAY1.shadow-text_negativeTextShadow__Jkqzp.shadow-text_sizeSmallMedium__nr217 > div > div'
      );

      if (nodoPuntos) {
        const puntosPantalla = parseInt(nodoPuntos.textContent.trim(), 10);

        if (!isNaN(puntosPantalla) && puntosPantalla >= 0 && puntosPantalla <= 5000) {
          if (puntosPantalla > maxPuntosRondaActiva) {
            maxPuntosRondaActiva = puntosPantalla;
          }
        }
      }

      // 4. Detectar final de partida
      const textoBoton = botonCerrar.innerText || botonCerrar.textContent;
      const esVerResultados =
        textoBoton.toLowerCase().includes("ver resultados") ||
        textoBoton.toLowerCase().includes("summary");

      if (esVerResultados && !temporizadorFinalIniciado && ultimoUsuario) {
        temporizadorFinalIniciado = true;

        console.log("[Ranking] Botón final detectado. Esperando 2 segundos...");

        setTimeout(() => {

          puntosTotales += Math.max(0, maxPuntosRondaActiva);

          console.log("[Ranking] ENVIANDO ->", puntosTotales);

          const url = window.location.href;
          let dif = "Desconocida";

          if (url.includes("nnTSJIccalcpyl4F")) dif = "Fácil";
          else if (url.includes("jdZO0BdNSVgLVeI0")) dif = "Medio";
          else if (url.includes("NACbl3PruMkTKmeb")) dif = "Difícil";
          else if (url.includes("mBBKOpmgVTtCrVvl")) dif = "Extremo";

          chrome.runtime.sendMessage({
            action: "sendData",
            data: {
              usuario: ultimoUsuario,
              puntuacion: puntosTotales,
              dificultad: dif
            }
          });

        }, 2000);
      }

    } else if (pantallaPuntosVisible) {

      // Cambio de ronda (1–4)
      const puntosASumar = Math.max(0, maxPuntosRondaActiva);

      puntosTotales += puntosASumar;

      console.log(
        `[Ranking] Ronda completada. +${puntosASumar} pts | Total: ${puntosTotales}`
      );

      maxPuntosRondaActiva = -1;
      pantallaPuntosVisible = false;
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

})();