(function() {
  console.log("[GeoGuessr Tracker] Iniciado. Motor de extracción por bloques numéricos activo.");
  let ultimoUsuario = "";
  let puntosTotales = 0;
  let maxPuntosRondaActiva = -1; // -1 para asegurar que el 0 también se detecte y sume
  let pantallaPuntosVisible = false;
  let temporizadorFinalIniciado = false;

  const obtenerInputUsuario = () => document.querySelector('input[placeholder*="apodo" i]') || document.querySelector('input[placeholder*="nick" i]') || document.querySelector('input[placeholder*="name" i]') || document.querySelector('input[type="text"]');

  const observer = new MutationObserver(() => {
    // 1. Guardar nombre del usuario en caché
    const inputUsr = obtenerInputUsuario();
    if (inputUsr && inputUsr.value.trim()) ultimoUsuario = inputUsr.value.trim();

    // 2. Localizar el botón de la ronda (Siguiente ronda / Ver resultados)
    const botonCerrar = document.querySelector('button[data-qa="close-round-result"]');
    // OffsetParent se asegura de que el elemento existe y es VISIBLE en pantalla
    const botonVisible = botonCerrar && botonCerrar.offsetParent !== null;

    if (botonVisible) {
      pantallaPuntosVisible = true;
      
      // 3. Extraer puntos. Buscamos el div con sombra.
      const divSombra = document.querySelector('[class*="shadow-text_root"]');
      if (divSombra) {
        const textoPlano = divSombra.innerText || divSombra.textContent;
        // Expresión regular que aísla solo bloques de números puros ("3277 De 5000" -> saca solo el "3277")
        const numeros = textoPlano.match(/\d+/g);
        
        if (numeros && numeros.length > 0) {
          const puntosPantalla = parseInt(numeros[0], 10);
          
          // Si el número es válido y supera al registrado en la animación actual, lo guardamos
          if (!isNaN(puntosPantalla) && puntosPantalla >= 0 && puntosPantalla <= 5000) {
            if (puntosPantalla > maxPuntosRondaActiva) {
              maxPuntosRondaActiva = puntosPantalla;
            }
          }
        }
      }

      // 4. Ver si estamos en la ronda final
      const textoBoton = botonCerrar.innerText || botonCerrar.textContent;
      const esVerResultados = textoBoton.toLowerCase().includes("ver resultados") || textoBoton.toLowerCase().includes("summary");

      // Si es el botón final, lanzamos un retraso de 2 segundos para dar tiempo a la animación
      if (esVerResultados && !temporizadorFinalIniciado && ultimoUsuario) {
        temporizadorFinalIniciado = true;
        console.log("[Ranking] Botón final detectado. Esperando 2 segundos para la estabilización de los puntos...");
        
        setTimeout(() => {
          // Sumamos lo que haya conseguido en la ronda 5
          puntosTotales += Math.max(0, maxPuntosRondaActiva);
          console.log("[Ranking] ¡ENVIANDO PUNTOS TOTALES A GOOGLE SHEETS! ->", puntosTotales);
          
          const url = window.location.href;
          let dif = "Desconocida";
          if (url.includes("nnTSJIccalcpyl4F")) dif = "Fácil";
          else if (url.includes("jdZO0BdNSVgLVeI0")) dif = "Medio";
          else if (url.includes("NACbl3PruMkTKmeb")) dif = "Difícil";
          else if (url.includes("mBBKOpmgVTtCrVvl")) dif = "Extremo";
          
          chrome.runtime.sendMessage({ 
            action: "sendData", 
            data: { usuario: ultimoUsuario, puntuacion: puntosTotales, dificultad: dif }
          });
        }, 2000); 
      }
      
    } else if (pantallaPuntosVisible) {
      // Si el botón ya no está visible, significa que el usuario pasó de ronda (rondas 1 a 4)
      const puntosASumar = Math.max(0, maxPuntosRondaActiva);
      puntosTotales += puntosASumar;
      console.log(`[Ranking] Ronda completada. Se suman ${puntosASumar} pts. Acumulado total: ${puntosTotales} pts.`);
      
      // Reseteamos el medidor para la ronda que viene
      maxPuntosRondaActiva = -1; 
      pantallaPuntosVisible = false;
    }
  });
  
  observer.observe(document.body, { childList: true, subtree: true });
})();