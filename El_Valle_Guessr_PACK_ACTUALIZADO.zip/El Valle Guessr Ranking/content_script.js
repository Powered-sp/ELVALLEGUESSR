(function() {
  console.log("[GeoGuessr Tracker] Content script cargado (Suma por Rondas)");

  let ultimoUsuario = "";
  let puntosTotales = 0;
  let rondasProcesadas = new Set();
  let enviadoFinal = false;

  const obtenerInputUsuario = () => {
    return document.querySelector('input[placeholder*="apodo" i]') || 
           document.querySelector('input[placeholder*="nick" i]') || 
           document.querySelector('input[placeholder*="name" i]') || 
           document.querySelector('main input[type="text"]') ||
           document.querySelector('input[type="text"]');
  };

  // Función para capturar el número de ronda actual en la pantalla de resultados de ronda
  const obtenerNumeroRonda = () => {
    // Busca el texto clásico "Ronda X / 5" o similar
    const elementos = document.querySelectorAll('*');
    for (let el of elementos) {
      if (el.childNodes.length === 1 && el.textContent.includes("Ronda")) {
        const match = el.textContent.match(/Ronda\s*([1-5])/i);
        if (match) return parseInt(match[1], 10);
      }
    }
    // Alternativa por selectores comunes de cabecera de ronda
    const cabeceraRonda = document.querySelector('[class*="round-result_title"]');
    if (cabeceraRonda) {
      const match = cabeceraRonda.textContent.match(/([1-5])/);
      if (match) return parseInt(match[1], 10);
    }
    return null;
  };

  const observer = new MutationObserver(() => {
    // 1. Guardar apodo mientras el input esté disponible
    const inputUsuario = obtenerInputUsuario();
    if (inputUsuario) {
      const valorActual = inputUsuario.value.trim();
      if (valorActual && valorActual !== ultimoUsuario) {
        ultimoUsuario = valorActual;
        console.log("[GeoGuessr Tracker] Usuario detectado:", ultimoUsuario);
      }
    }

    // 2. Detectar puntos de la ronda actual
    const wrapperPuntos = document.querySelector('.round-result_pointsIndicatorWrapper__7JxD_');
    if (wrapperPuntos) {
      const divTexto = wrapperPuntos.querySelector('.shadow-text_root__KeAY1');
      if (divTexto) {
        const textoLimpio = divTexto.textContent.replace(/[^0-9]/g, '');
        const puntosRonda = parseInt(textoLimpio, 10);

        if (!isNaN(puntosRonda) && puntosRonda <= 5000) {
          // Intentamos identificar qué ronda es
          let rondaActual = obtenerNumeroRonda();
          
          // Si no se encuentra explícitamente el número de ronda por texto, usamos un fallback inteligente
          // Basado en el tamaño del Set para que avance de forma secuencial
          if (!rondaActual) {
            rondaActual = rondasProcesadas.size + 1;
          }

          // Si esta ronda no la hemos sumado todavía
          if (!rondasProcesadas.has(rondaActual)) {
            rondasProcesadas.add(rondaActual);
            puntosTotales += puntosRonda;
            console.log(`[GeoGuessr Tracker] Ronda ${rondaActual} sumada: ${puntosRonda} pts. Total acumulado: ${puntosTotales} pts.`);

            // Si es la ronda 5 y aún no se ha mandado el total final
            if (rondaActual === 5 && !enviadoFinal && ultimoUsuario) {
              enviadoFinal = true;
              
              const url = window.location.href;
              let dificultad = "Desconocida";
              if (url.includes("nnTSJIccalcpyl4F")) dificultad = "Fácil";
              else if (url.includes("jdZO0BdNSVgLVeI0")) dificultad = "Medio";
              else if (url.includes("NACbl3PruMkTKmeb")) dificultad = "Difícil";
              else if (url.includes("mBBKOpmgVTtCrVvl")) dificultad = "Extremo";

              console.log("[GeoGuessr Tracker] ¡Ronda 5 completada! Enviando total definitivo:", puntosTotales);
              
              chrome.runtime.sendMessage({
                action: "sendData",
                data: { usuario: ultimoUsuario, puntuacion: puntosTotales, dificultad: dificultad }
              });
            }
          }
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();