
const allowedDomains = [
  "sites.google.com",
  "www.geoguessr.com"
];

function isAllowed(urlString) {
  try {
    const url = new URL(urlString);
    return allowedDomains.includes(url.hostname);
  } catch (e) {
    return true; // Si no se puede parsear, mejor no cerrarla.
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = changeInfo.url || tab.url;
  if (url && !isAllowed(url)) {
    chrome.tabs.remove(tabId);
  }
});

chrome.tabs.onCreated.addListener((tab) => {
  const url = tab.pendingUrl || tab.url;
  if (url && !isAllowed(url)) {
    chrome.tabs.remove(tab.id);
  }
});
