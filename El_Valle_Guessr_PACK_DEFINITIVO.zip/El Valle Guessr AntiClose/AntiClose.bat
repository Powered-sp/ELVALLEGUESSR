@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "AntiClose.ps1"